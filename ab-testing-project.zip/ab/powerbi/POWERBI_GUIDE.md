# Power BI dashboard guide

A `.pbix` can't be generated outside Power BI Desktop, so this gives the exact model, measures and layout
(about 30-45 minutes to build).

## 1. Load (Get Data -> Text/CSV) from `outputs/tables/`
| Table | File | Grain |
|---|---|---|
| clean_events | clean_events.csv | 1 row per user (50,000) |
| frequentist_results | frequentist_results.csv | 1 row per metric |
| bayesian_results | bayesian_results.csv | 1 row per metric |
| prior_sensitivity | prior_sensitivity.csv | metric x prior |
| posterior_hist | posterior_hist.csv | posterior histogram bins |
| segment_results | segment_results.csv | segment x metric |
| heterogeneity_tests | heterogeneity_tests.csv | desktop vs mobile effect tests |
| power_mde | power_mde.csv | MDE and sample-size tables |
| validation_report | validation_report.csv | data-quality checks |
| daily_metrics | daily_metrics.csv | day x variant |
| recommendation | recommendation.csv | verdict per scope |

No relationships are required: every analysis table is pre-aggregated. Optionally slice `clean_events`
by `device`, `plan`, `user_type` for the headline cards.

## 2. DAX measures (on `clean_events`)
```DAX
Users             = COUNTROWS ( clean_events )
Conversion Rate   = AVERAGE ( clean_events[converted] )
CTR               = AVERAGE ( clean_events[clicked] )
Avg Session Min   = AVERAGE ( clean_events[session_minutes] )
Control Conv      = CALCULATE ( [Conversion Rate], clean_events[variant] = "control" )
Treatment Conv    = CALCULATE ( [Conversion Rate], clean_events[variant] = "treatment" )
Conv Lift %       = DIVIDE ( [Treatment Conv] - [Control Conv], [Control Conv] )
Control CTR       = CALCULATE ( [CTR], clean_events[variant] = "control" )
Treatment CTR     = CALCULATE ( [CTR], clean_events[variant] = "treatment" )
CTR Lift %        = DIVIDE ( [Treatment CTR] - [Control CTR], [Control CTR] )
Session Change %  = DIVIDE (
    CALCULATE ( [Avg Session Min], clean_events[variant] = "treatment" )
  - CALCULATE ( [Avg Session Min], clean_events[variant] = "control" ),
    CALCULATE ( [Avg Session Min], clean_events[variant] = "control" ) )
Guardrail Breached = IF ( [Session Change %] < -0.03, "BREACH", "OK" )
```
Format rates and lifts as `0.0%`. Note: the p-values, confidence intervals and Bayesian numbers come from the
Python tables, not DAX, so keep the analysis tables as the source for significance.

## 3. Pages
1. **Decision summary** - headline text from `recommendation[headline]`; table of `recommendation` (scope, verdict,
   conversion lift, session change); colour verdict cells (green = SHIP, red = DO NOT SHIP, amber = INCONCLUSIVE).
2. **Experiment results** - cards for Conv Lift %, CTR Lift %, Session Change %; clustered bars for control vs
   treatment rates; table of `frequentist_results` (lift, CI, p-value).
3. **Bayesian view** - bar chart of `posterior_hist` (x=bin_mid, y=share; colour by above_zero) filtered by metric;
   cards for `prob_treatment_better` and `exp_loss_ship`; table `prior_sensitivity` ("conclusion robust to prior").
4. **Segments** - forest-style chart from `segment_results` (abs_diff with ci_low/ci_high) filtered to
   metric = conversion; matrix of segment x metric with `p_adj_bh`; include the `heterogeneity_tests` table.
5. **Power & data quality** - line chart `power_mde` (table = mde_vs_sample; x=n_per_arm, y=mde_rel, legend=metric);
   table of `n_needed`; `validation_report` table with status colouring; `daily_metrics` cumulative line.

## 4. Storytelling tips
Title every page with the takeaway ("Desktop converts +30%; mobile loses 8.6% session time"), keep a
visible "Simulated data" footnote, and show uncertainty (CIs) next to every point estimate.
