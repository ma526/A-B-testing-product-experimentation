"""
End-to-end A/B analysis: SQL metrics -> data validation -> frequentist tests -> Bayesian
Beta-Binomial (Monte Carlo) -> power / MDE -> segment analysis -> ship / no-ship recommendation.

Pre-registered decision framework (decided BEFORE looking at results):
  Primary metric : conversion rate           (ship only if significant AND P(treatment > control) >= 0.95)
  Secondary      : click-through rate
  Guardrail      : average session minutes   (violated if relative drop > 3% AND p < 0.05)

    python src/analyze.py --data data --sql sql --out outputs
"""
import argparse
import glob
import os
import re
import sqlite3

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ALPHA = 0.05
Z = stats.norm.ppf(1 - ALPHA / 2)
GUARDRAIL_DROP = -0.03          # relative change in session minutes that counts as harm
BAYES_THRESHOLD = 0.95
N_DRAWS = 200_000
HIST_BASELINE = {"ctr": 0.12, "conversion": 0.04}   # "last quarter" baselines for the informative prior
PRIOR_STRENGTH = 200                                  # pseudo-observations in the informative prior
COLORS = {"control": "#7A8499", "treatment": "#5B6CFF"}


# ------------------------------------------------------------------ SQL layer
def run_sql(raw, sql_dir):
    con = sqlite3.connect(":memory:")
    raw.to_sql("experiment_events", con, index=False)
    out = {}
    for path in sorted(glob.glob(os.path.join(sql_dir, "[0-9]*.sql"))):
        name = re.sub(r"^\d+_", "", os.path.splitext(os.path.basename(path))[0])
        q = open(path).read().strip().rstrip(";")
        if name == "clean_events":
            con.execute(f"CREATE TABLE clean_events AS {q}")
            out[name] = pd.read_sql("SELECT * FROM clean_events", con)
        else:
            out[name] = pd.read_sql(q, con)
    return out


# ------------------------------------------------------------------ validation
def validate(raw, clean, sql_variant):
    rows = []

    def add(check, value, status, note=""):
        rows.append({"check": check, "value": value, "status": status, "note": note})

    add("Raw rows", len(raw), "INFO")
    dup = len(raw) - raw.user_id.nunique()
    add("Duplicate exposure rows removed", dup, "FIXED" if dup else "PASS", "kept each user's first record")
    n_null = int(raw.session_minutes.isna().sum())
    n_bad = int((raw.session_minutes <= 0).sum())
    add("Missing session durations", n_null, "FIXED" if n_null else "PASS", "excluded from session metric only")
    add("Invalid (<=0) session durations", n_bad, "FIXED" if n_bad else "PASS", "treated as missing")
    add("Unique users analysed", len(clean), "INFO")

    counts = clean.variant.value_counts().reindex(["control", "treatment"]).to_numpy()
    p_srm = stats.chisquare(counts).pvalue
    add("Sample ratio mismatch (50/50 split)", f"{counts[0]:,} vs {counts[1]:,}  (p={p_srm:.3f})",
        "PASS" if p_srm > 0.001 else "FAIL", "chi-square goodness of fit; fail if p < 0.001")
    for col in ["device", "plan", "user_type"]:
        p = stats.chi2_contingency(pd.crosstab(clean.variant, clean[col]))[1]
        add(f"Covariate balance: {col}", f"p={p:.3f}", "PASS" if p > 0.01 else "WARN",
            "randomisation check: arms should look alike")
    ts = pd.to_datetime(clean.event_ts)
    days = (ts.max() - ts.min()).days + 1
    add("Test duration (days)", days, "PASS" if days >= 14 else "WARN", "full weekly cycles reduce day-of-week bias")

    sv = sql_variant.set_index("variant")
    ok = all(int(sv.loc[v, "conversions"]) == int(clean.loc[clean.variant == v, "converted"].sum())
             for v in ["control", "treatment"])
    add("SQL vs Python reconciliation (conversions)", "match" if ok else "MISMATCH", "PASS" if ok else "FAIL")
    return pd.DataFrame(rows)


# ------------------------------------------------------------------ frequentist
def two_prop(x1, n1, x2, n2):
    """control=(x1,n1), treatment=(x2,n2). Pooled z-test, Wald CI, delta-method CI for relative lift, chi-square."""
    p1, p2 = x1 / n1, x2 / n2
    pp = (x1 + x2) / (n1 + n2)
    z = (p2 - p1) / np.sqrt(pp * (1 - pp) * (1 / n1 + 1 / n2))
    se = np.sqrt(p1 * (1 - p1) / n1 + p2 * (1 - p2) / n2)
    d = p2 - p1
    chi2, p_chi, _, _ = stats.chi2_contingency([[x1, n1 - x1], [x2, n2 - x2]], correction=False)
    log_rr, se_log = np.log(p2 / p1), np.sqrt((1 - p1) / x1 + (1 - p2) / x2) if x1 and x2 else (np.nan, np.nan)
    return {"control_rate": p1, "treatment_rate": p2, "abs_diff": d, "ci_low": d - Z * se, "ci_high": d + Z * se,
            "rel_lift": p2 / p1 - 1, "rel_ci_low": np.exp(log_rr - Z * se_log) - 1,
            "rel_ci_high": np.exp(log_rr + Z * se_log) - 1, "z": z, "p_value": 2 * stats.norm.sf(abs(z)),
            "chi2": chi2, "chi2_p": p_chi}


def welch(ctrl, trt):
    r = stats.ttest_ind(trt, ctrl, equal_var=False)
    ci = r.confidence_interval(0.95)
    m1, m2 = ctrl.mean(), trt.mean()
    sp = np.sqrt((ctrl.var(ddof=1) + trt.var(ddof=1)) / 2)
    return {"control_mean": m1, "treatment_mean": m2, "abs_diff": m2 - m1, "ci_low": ci.low, "ci_high": ci.high,
            "rel_lift": m2 / m1 - 1, "rel_ci_low": ci.low / m1, "rel_ci_high": ci.high / m1,
            "t": r.statistic, "p_value": r.pvalue, "cohens_d": (m2 - m1) / sp}


def bh_adjust(p):
    """Benjamini-Hochberg FDR-adjusted p-values."""
    p = np.asarray(p, float)
    order = np.argsort(p)
    ranked = p[order] * len(p) / (np.arange(len(p)) + 1)
    adj = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty_like(adj)
    out[order] = np.minimum(adj, 1)
    return out


# ------------------------------------------------------------------ Bayesian
def bayes(x1, n1, x2, n2, prior=(1, 1), draws=N_DRAWS, seed=11):
    rng = np.random.default_rng(seed)
    pc = rng.beta(prior[0] + x1, prior[1] + n1 - x1, draws)
    pt = rng.beta(prior[0] + x2, prior[1] + n2 - x2, draws)
    lift = pt / pc - 1
    return {"prob_treatment_better": float((pt > pc).mean()), "exp_rel_lift": float(lift.mean()),
            "cri_low": float(np.percentile(lift, 2.5)), "cri_high": float(np.percentile(lift, 97.5)),
            "exp_loss_ship": float(np.maximum(pc - pt, 0).mean()),          # cost if we ship and T is worse
            "exp_loss_hold": float(np.maximum(pt - pc, 0).mean())}, lift     # cost if we keep control and T is better


# ------------------------------------------------------------------ power / MDE
def n_per_arm(p1, rel_lift, power=0.8):
    p2 = p1 * (1 + rel_lift)
    return int(np.ceil((Z + stats.norm.ppf(power)) ** 2 * (p1 * (1 - p1) + p2 * (1 - p2)) / (p2 - p1) ** 2))


def mde_abs(p1, n, power=0.8):
    zb = stats.norm.ppf(power)
    d = (Z + zb) * np.sqrt(2 * p1 * (1 - p1) / n)
    for _ in range(6):
        d = (Z + zb) * np.sqrt((p1 * (1 - p1) + (p1 + d) * (1 - p1 - d)) / n)
    return d


def power_tables(base, n_each):
    rows = []
    for metric, p1 in base.items():
        for n in [2_500, 5_000, 10_000, 15_000, 20_000, 25_000, 40_000, 60_000, 100_000]:
            d = mde_abs(p1, n)
            rows.append({"table": "mde_vs_sample", "metric": metric, "baseline": p1, "n_per_arm": n,
                         "mde_abs": d, "mde_rel": d / p1, "is_actual_n": n == round(n_each, -3)})
        rows.append({"table": "mde_vs_sample", "metric": metric, "baseline": p1, "n_per_arm": int(n_each),
                     "mde_abs": mde_abs(p1, n_each), "mde_rel": mde_abs(p1, n_each) / p1, "is_actual_n": True})
        for rel in [0.05, 0.10, 0.15, 0.20, 0.25]:
            rows.append({"table": "n_needed", "metric": metric, "baseline": p1, "rel_lift": rel,
                         "n_per_arm": n_per_arm(p1, rel)})
    return pd.DataFrame(rows)


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--sql", default="sql")
    ap.add_argument("--out", default="outputs")
    args = ap.parse_args()
    tdir, fdir = os.path.join(args.out, "tables"), os.path.join(args.out, "figures")
    os.makedirs(tdir, exist_ok=True)
    os.makedirs(fdir, exist_ok=True)

    raw = pd.read_csv(os.path.join(args.data, "experiment_events.csv"))
    sql = run_sql(raw, args.sql)
    clean = sql["clean_events"]
    clean.to_csv(os.path.join(tdir, "clean_events.csv"), index=False)
    sql["daily_metrics"].to_csv(os.path.join(tdir, "daily_metrics.csv"), index=False)

    val = validate(raw, clean, sql["metrics_by_variant"])
    val.to_csv(os.path.join(tdir, "validation_report.csv"), index=False)
    print("VALIDATION\n", val.to_string(index=False), "\n")

    c, t = clean[clean.variant == "control"], clean[clean.variant == "treatment"]
    n1, n2 = len(c), len(t)

    # ---------- frequentist, overall
    freq = []
    for metric, col in [("conversion", "converted"), ("ctr", "clicked")]:
        r = two_prop(c[col].sum(), n1, t[col].sum(), n2)
        freq.append({"metric": metric, "test": "two-proportion z-test", **r})
    ws = welch(c.session_minutes.dropna(), t.session_minutes.dropna())
    freq.append({"metric": "avg_session_minutes", "test": "Welch t-test", **ws})
    freq = pd.DataFrame(freq)
    freq.to_csv(os.path.join(tdir, "frequentist_results.csv"), index=False)
    print("FREQUENTIST\n", freq[["metric", "abs_diff", "rel_lift", "rel_ci_low", "rel_ci_high", "p_value"]]
          .round(5).to_string(index=False), "\n")

    # ---------- Bayesian, overall + prior sensitivity
    bay_rows, hist_rows, sens_rows = [], [], []
    for metric, col in [("conversion", "converted"), ("ctr", "clicked")]:
        x1, x2 = int(c[col].sum()), int(t[col].sum())
        res, lift = bayes(x1, n1, x2, n2)
        bay_rows.append({"metric": metric, "prior": "Beta(1,1) weak", **res})
        counts, edges = np.histogram(lift, bins=60, range=(np.percentile(lift, .1), np.percentile(lift, 99.9)))
        for k in range(len(counts)):
            hist_rows.append({"metric": metric, "bin_mid": (edges[k] + edges[k + 1]) / 2,
                              "share": counts[k] / len(lift), "above_zero": (edges[k] + edges[k + 1]) / 2 > 0})
        h = HIST_BASELINE[metric]
        priors = {"Beta(1,1) weak": (1, 1), "Beta(0.5,0.5) Jeffreys": (.5, .5),
                  f"Informative (baseline {h:.0%}, {PRIOR_STRENGTH} pseudo-obs)": (h * PRIOR_STRENGTH, (1 - h) * PRIOR_STRENGTH)}
        for pname, pr in priors.items():
            r2, _ = bayes(x1, n1, x2, n2, prior=pr, draws=100_000)
            sens_rows.append({"metric": metric, "prior": pname, **r2})
    bay = pd.DataFrame(bay_rows)
    bay.to_csv(os.path.join(tdir, "bayesian_results.csv"), index=False)
    pd.DataFrame(sens_rows).to_csv(os.path.join(tdir, "prior_sensitivity.csv"), index=False)
    pd.DataFrame(hist_rows).to_csv(os.path.join(tdir, "posterior_hist.csv"), index=False)
    print("BAYESIAN\n", bay.round(4).to_string(index=False), "\n")

    # ---------- power / MDE
    base = {"conversion": c.converted.mean(), "ctr": c.clicked.mean()}
    pw = power_tables(base, n1)
    pw.to_csv(os.path.join(tdir, "power_mde.csv"), index=False)
    mde_now = {m: mde_abs(p, n1) for m, p in base.items()}
    print("MDE at current n (80% power):", {k: round(v, 4) for k, v in mde_now.items()}, "\n")

    # ---------- segments
    seg_rows = []
    for dim in ["device", "plan", "user_type"]:
        for seg, g in clean.groupby(dim):
            gc, gt = g[g.variant == "control"], g[g.variant == "treatment"]
            for metric, col in [("conversion", "converted"), ("ctr", "clicked")]:
                r = two_prop(gc[col].sum(), len(gc), gt[col].sum(), len(gt))
                pb, _ = bayes(int(gc[col].sum()), len(gc), int(gt[col].sum()), len(gt), draws=50_000)
                seg_rows.append({"dimension": dim, "segment": seg, "metric": metric, "n_control": len(gc),
                                 "n_treatment": len(gt), **{k: r[k] for k in
                                 ["control_rate", "treatment_rate", "abs_diff", "ci_low", "ci_high",
                                  "rel_lift", "p_value"]}, "prob_treatment_better": pb["prob_treatment_better"]})
            w = welch(gc.session_minutes.dropna(), gt.session_minutes.dropna())
            seg_rows.append({"dimension": dim, "segment": seg, "metric": "avg_session_minutes",
                             "n_control": len(gc), "n_treatment": len(gt),
                             **{k: w[k] for k in ["abs_diff", "ci_low", "ci_high", "rel_lift", "p_value"]},
                             "control_rate": w["control_mean"], "treatment_rate": w["treatment_mean"],
                             "prob_treatment_better": np.nan})
    seg = pd.DataFrame(seg_rows)
    seg["p_adj_bh"] = np.nan
    for m in seg.metric.unique():                       # one FDR family per metric (8 segment tests each)
        idx = seg.metric == m
        seg.loc[idx, "p_adj_bh"] = bh_adjust(seg.loc[idx, "p_value"])
    seg.to_csv(os.path.join(tdir, "segment_results.csv"), index=False)

    # heterogeneity: is the desktop effect really different from the mobile effect?
    het = []
    for metric, col in [("conversion", "converted"), ("ctr", "clicked"), ("avg_session_minutes", None)]:
        eff = {}
        for dv in ["desktop", "mobile"]:
            g = clean[clean.device == dv]
            gc, gt = g[g.variant == "control"], g[g.variant == "treatment"]
            if col:
                p1, p2 = gc[col].mean(), gt[col].mean()
                eff[dv] = (p2 - p1, np.sqrt(p1 * (1 - p1) / len(gc) + p2 * (1 - p2) / len(gt)))
            else:
                a, b = gc.session_minutes.dropna(), gt.session_minutes.dropna()
                eff[dv] = (b.mean() - a.mean(), np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b)))
        dz = (eff["desktop"][0] - eff["mobile"][0]) / np.hypot(eff["desktop"][1], eff["mobile"][1])
        het.append({"metric": metric, "desktop_effect": eff["desktop"][0], "mobile_effect": eff["mobile"][0],
                    "difference": eff["desktop"][0] - eff["mobile"][0], "z": dz, "p_value": 2 * stats.norm.sf(abs(dz))})
    het = pd.DataFrame(het)
    het.to_csv(os.path.join(tdir, "heterogeneity_tests.csv"), index=False)
    print("HETEROGENEITY (desktop vs mobile effect)\n", het.round(4).to_string(index=False), "\n")

    # ---------- decision
    def verdict(conv_sig_pos, guard):
        if conv_sig_pos and not guard:
            return "SHIP"
        if conv_sig_pos and guard:
            return "DO NOT SHIP AS-IS (guardrail violated)"
        if guard:
            return "DO NOT SHIP (guardrail harm, no conversion gain)"
        return "INCONCLUSIVE (extend test or iterate)"

    rec = []
    fc = freq.set_index("metric")
    conv_sig = fc.loc["conversion", "p_value"] < ALPHA and fc.loc["conversion", "abs_diff"] > 0 \
        and bay.set_index("metric").loc["conversion", "prob_treatment_better"] >= BAYES_THRESHOLD
    guard = fc.loc["avg_session_minutes", "rel_lift"] < GUARDRAIL_DROP and fc.loc["avg_session_minutes", "p_value"] < ALPHA
    rec.append({"scope": "Overall", "verdict": verdict(conv_sig, guard),
                "conversion_rel_lift": fc.loc["conversion", "rel_lift"], "conversion_p": fc.loc["conversion", "p_value"],
                "prob_treatment_better": bay.set_index("metric").loc["conversion", "prob_treatment_better"],
                "session_rel_change": fc.loc["avg_session_minutes", "rel_lift"],
                "session_p": fc.loc["avg_session_minutes", "p_value"], "guardrail_violated": bool(guard)})
    for dv in ["desktop", "mobile", "tablet"]:
        s = seg[(seg.dimension == "device") & (seg.segment == dv)].set_index("metric")
        cs = s.loc["conversion", "p_adj_bh"] < ALPHA and s.loc["conversion", "abs_diff"] > 0 \
            and s.loc["conversion", "prob_treatment_better"] >= BAYES_THRESHOLD
        gd = s.loc["avg_session_minutes", "rel_lift"] < GUARDRAIL_DROP and s.loc["avg_session_minutes", "p_adj_bh"] < ALPHA
        rec.append({"scope": f"Device: {dv}", "verdict": verdict(cs, gd),
                    "conversion_rel_lift": s.loc["conversion", "rel_lift"], "conversion_p": s.loc["conversion", "p_adj_bh"],
                    "prob_treatment_better": s.loc["conversion", "prob_treatment_better"],
                    "session_rel_change": s.loc["avg_session_minutes", "rel_lift"],
                    "session_p": s.loc["avg_session_minutes", "p_adj_bh"], "guardrail_violated": bool(gd)})
    rec = pd.DataFrame(rec)
    # an average can hide harm: if the overall result is a SHIP but a device segment breaches the guardrail
    # (and the segment effects differ significantly), do not ship to everyone.
    if rec.iloc[0].verdict == "SHIP" and rec.iloc[1:].guardrail_violated.any():
        rec.loc[0, "verdict"] = "SHIP TO SEGMENTS ONLY (guardrail breached in a segment)"
    ship = rec[(rec.scope != "Overall") & (rec.verdict == "SHIP")].scope.str.replace("Device: ", "").tolist()
    hold = rec[(rec.scope != "Overall") & (rec.verdict != "SHIP")].scope.str.replace("Device: ", "").tolist()
    if rec.iloc[0].verdict == "SHIP":
        headline = "SHIP to all users."
    elif ship:
        headline = f"SHIP to {', '.join(ship)} only; hold {', '.join(hold)} and iterate."
    else:
        headline = "DO NOT SHIP; iterate or extend the test."
    rec["headline"] = headline
    rec.to_csv(os.path.join(tdir, "recommendation.csv"), index=False)
    print("RECOMMENDATION:", headline)
    print(rec.drop(columns="headline").round(4).to_string(index=False), "\n")

    make_figures(fdir, clean, freq, bay, seg, pw, base, n1, sql["daily_metrics"], pd.DataFrame(hist_rows))
    print("Saved tables and figures.")


# ------------------------------------------------------------------ figures
def make_figures(fdir, clean, freq, bay, seg, pw, base, n1, daily, hist):
    f = freq.set_index("metric")
    fig, ax = plt.subplots(figsize=(6.5, 3.6))
    names = ["ctr", "conversion", "avg_session_minutes"]
    lift = [f.loc[m, "rel_lift"] * 100 for m in names]
    lo = [lift[i] - f.loc[m, "rel_ci_low"] * 100 for i, m in enumerate(names)]
    hi = [f.loc[m, "rel_ci_high"] * 100 - lift[i] for i, m in enumerate(names)]
    ax.errorbar(lift, range(3), xerr=[lo, hi], fmt="o", color="#5B6CFF", capsize=4)
    ax.axvline(0, color="k", lw=1); ax.axvline(GUARDRAIL_DROP * 100, color="#C0392B", ls="--", lw=1)
    ax.set_yticks(range(3)); ax.set_yticklabels(["CTR", "Conversion", "Session minutes\n(guardrail)"])
    ax.set_xlabel("Relative lift, % (95% CI)"); ax.set_title("Treatment vs control"); plt.tight_layout()
    plt.savefig(os.path.join(fdir, "lift_overview.png"), dpi=150); plt.close()

    fig, axes = plt.subplots(1, 2, figsize=(9, 3.4))
    for ax, m in zip(axes, ["conversion", "ctr"]):
        h = hist[hist.metric == m]
        ax.bar(h.bin_mid * 100, h.share, width=(h.bin_mid.diff().median()) * 100,
               color=np.where(h.above_zero, "#5B6CFF", "#C0392B"))
        ax.set_title(f"{m.upper() if m == 'ctr' else 'Conversion'}: P(T>C)={bay.set_index('metric').loc[m, 'prob_treatment_better']:.3f}")
        ax.set_xlabel("Posterior relative lift, %"); ax.set_yticks([])
    plt.tight_layout(); plt.savefig(os.path.join(fdir, "bayesian_posterior.png"), dpi=150); plt.close()

    plt.figure(figsize=(6.5, 4))
    for m, col in [("conversion", "#5B6CFF"), ("ctr", "#16A085")]:
        d = pw[(pw.table == "mde_vs_sample") & (pw.metric == m)].sort_values("n_per_arm")
        plt.plot(d.n_per_arm, d.mde_rel * 100, marker="o", label=m, color=col)
    plt.axvline(n1, color="k", ls="--", lw=1, label=f"this test ({n1:,}/arm)")
    plt.xscale("log"); plt.xlabel("Users per arm"); plt.ylabel("Minimum detectable effect (relative %), 80% power")
    plt.title("MDE sensitivity"); plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(fdir, "mde_sensitivity.png"), dpi=150); plt.close()

    s = seg[seg.metric == "conversion"].copy()
    s["label"] = s.dimension + ": " + s.segment
    s = s.iloc[::-1]
    plt.figure(figsize=(7, 4.5))
    cols = np.where((s.p_adj_bh < ALPHA), "#5B6CFF", "#7A8499")
    plt.errorbar(s.abs_diff * 100, range(len(s)), xerr=[(s.abs_diff - s.ci_low) * 100, (s.ci_high - s.abs_diff) * 100],
                 fmt="none", ecolor="#BBBBBB", capsize=3)
    plt.scatter(s.abs_diff * 100, range(len(s)), c=cols, zorder=3)
    plt.axvline(0, color="k", lw=1); plt.yticks(range(len(s)), s.label)
    plt.xlabel("Conversion lift, pp (95% CI); blue = significant after BH")
    plt.title("Conversion effect by segment"); plt.tight_layout()
    plt.savefig(os.path.join(fdir, "segment_forest.png"), dpi=150); plt.close()

    d = daily.copy()
    plt.figure(figsize=(6.5, 3.8))
    for v in ["control", "treatment"]:
        g = d[d.variant == v].sort_values("event_date")
        plt.plot(pd.to_datetime(g.event_date), g.conversions.cumsum() / g.users.cumsum() * 100, label=v, color=COLORS[v])
    plt.ylabel("Cumulative conversion %"); plt.title("Cumulative conversion rate over the test"); plt.legend()
    plt.xticks(rotation=30); plt.tight_layout(); plt.savefig(os.path.join(fdir, "cumulative_conversion.png"), dpi=150); plt.close()


if __name__ == "__main__":
    main()
