"""
Simulate a randomized A/B test: "AI template picker" (treatment) vs current homepage (control)
on a Figma-style design tool. 50,000 users, one exposure record per user.

IMPORTANT: SIMULATED data. The effects below are modelling assumptions chosen to create a realistic,
non-trivial decision (a clear CTR win, a modest conversion win that is concentrated in desktop users,
and a session-duration guardrail problem on mobile). Say so in your README / interviews.

    python src/simulate_experiment.py --users 50000 --out data
Output: data/experiment_events.csv
"""
import argparse
import os

import numpy as np
import pandas as pd

# ---- assumed truth (control baseline and treatment effects, by device) ----
BASE_CTR = 0.12
BASE_CONV = 0.040
BASE_SESSION_MIN = 8.0          # median-ish; lognormal
CTR_LIFT = {"desktop": 1.14, "mobile": 1.10, "tablet": 1.10}       # multiplicative on CTR
CONV_LIFT = {"desktop": 1.22, "mobile": 0.98, "tablet": 1.05}      # multiplicative on conversion
SESS_MULT = {"desktop": 1.01, "mobile": 0.91, "tablet": 0.98}      # multiplicative on session length
PLAN_CONV = {"Free": 0.85, "Professional": 1.25, "Organization": 1.45}
TYPE_CONV = {"new": 0.90, "returning": 1.12}


def simulate(n_users, seed):
    rng = np.random.default_rng(seed)
    device = rng.choice(["desktop", "mobile", "tablet"], n_users, p=[.55, .38, .07])
    plan = rng.choice(["Free", "Professional", "Organization"], n_users, p=[.65, .27, .08])
    user_type = rng.choice(["new", "returning"], n_users, p=[.55, .45])
    variant = rng.choice(["control", "treatment"], n_users)          # randomized 50/50
    t = variant == "treatment"

    ctr = np.full(n_users, BASE_CTR)
    conv = (BASE_CONV * np.vectorize(PLAN_CONV.get)(plan) * np.vectorize(TYPE_CONV.get)(user_type))
    sess_mu = np.log(BASE_SESSION_MIN) * np.ones(n_users)
    ctr = np.where(t, ctr * np.vectorize(CTR_LIFT.get)(device), ctr)
    conv = np.where(t, conv * np.vectorize(CONV_LIFT.get)(device), conv)
    sess_med = np.where(t, np.exp(sess_mu) * np.vectorize(SESS_MULT.get)(device), np.exp(sess_mu))

    clicked = rng.random(n_users) < ctr
    converted = rng.random(n_users) < conv
    session_minutes = rng.lognormal(np.log(sess_med), 0.8)

    ts = pd.Timestamp("2026-03-01") + pd.to_timedelta(rng.random(n_users) * 14, unit="D")  # 14-day test
    df = pd.DataFrame({
        "user_id": np.arange(1, n_users + 1), "variant": variant, "event_ts": ts,
        "device": device, "plan": plan, "user_type": user_type,
        "clicked": clicked.astype(int), "converted": converted.astype(int),
        "session_minutes": session_minutes.round(2)})
    return df.sort_values("event_ts").reset_index(drop=True)


def inject_quality_issues(df, seed):
    """Realistic dirt so the validation step has something to find."""
    rng = np.random.default_rng(seed + 7)
    n = len(df)
    df = df.copy()
    df.loc[rng.choice(n, 120, replace=False), "session_minutes"] = np.nan     # missing durations
    df.loc[rng.choice(n, 25, replace=False), "session_minutes"] = -1.0        # logging bug
    dups = df.sample(150, random_state=seed)                                  # double-fired exposures
    dups = dups.assign(event_ts=dups.event_ts + pd.to_timedelta(rng.integers(1, 60, len(dups)), unit="s"))
    return pd.concat([df, dups]).sort_values("event_ts").reset_index(drop=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--users", type=int, default=50_000)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--out", default="data")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    df = inject_quality_issues(simulate(args.users, args.seed), args.seed)
    df.insert(0, "event_id", np.arange(1, len(df) + 1))
    df["event_ts"] = df["event_ts"].dt.strftime("%Y-%m-%d %H:%M:%S")
    df.to_csv(os.path.join(args.out, "experiment_events.csv"), index=False)
    print(f"rows={len(df):,} (unique users={df.user_id.nunique():,}); incl. injected duplicates/bad values")


if __name__ == "__main__":
    main()
