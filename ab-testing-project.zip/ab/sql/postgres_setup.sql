-- Optional: run the same analysis in PostgreSQL (the numbered queries are portable ANSI SQL).
-- 1) create the raw table and load the CSV; 2) create clean_events from 01_clean_events.sql;
-- 3) run 02..04 as plain SELECTs.   (Not executed in the build environment; only SQLite was.)
CREATE TABLE experiment_events (
    event_id        INTEGER PRIMARY KEY,
    user_id         INTEGER NOT NULL,
    variant         VARCHAR(10) NOT NULL,
    event_ts        TIMESTAMP NOT NULL,
    device          VARCHAR(10),
    plan            VARCHAR(15),
    user_type       VARCHAR(10),
    clicked         SMALLINT,
    converted       SMALLINT,
    session_minutes NUMERIC(8,2)
);
-- \copy experiment_events FROM 'data/experiment_events.csv' CSV HEADER
-- CREATE TABLE clean_events AS <contents of 01_clean_events.sql>;
