-- De-duplicate exposures (keep each user's first record) and null out invalid session durations.
-- Invalid sessions are excluded from the session metric only; those users still count in CTR / conversion.
SELECT event_id, user_id, variant, event_ts, device, plan, user_type, clicked, converted,
       CASE WHEN session_minutes IS NULL OR session_minutes <= 0 THEN NULL ELSE session_minutes END AS session_minutes
FROM (
    SELECT e.*, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY event_ts, event_id) AS rn
    FROM experiment_events e
) t
WHERE rn = 1
