-- Daily volumes per variant (used for the "did results stabilise?" chart)
SELECT SUBSTR(CAST(event_ts AS VARCHAR(19)), 1, 10) AS event_date, variant,
       COUNT(*) AS users, SUM(clicked) AS clicks, SUM(converted) AS conversions
FROM clean_events
GROUP BY SUBSTR(CAST(event_ts AS VARCHAR(19)), 1, 10), variant
ORDER BY 1, 2
