-- Core treatment-vs-control metrics
SELECT variant,
       COUNT(*)                    AS users,
       SUM(clicked)                AS clicks,
       SUM(converted)              AS conversions,
       AVG(clicked * 1.0)          AS ctr,
       AVG(converted * 1.0)        AS conversion_rate,
       COUNT(session_minutes)      AS sessions_n,
       AVG(session_minutes)        AS avg_session_minutes
FROM clean_events
GROUP BY variant
ORDER BY variant
