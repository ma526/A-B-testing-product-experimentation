-- Same metrics split by device, plan and user type
SELECT 'device' AS dimension, device AS segment, variant, COUNT(*) AS users, SUM(clicked) AS clicks,
       SUM(converted) AS conversions, COUNT(session_minutes) AS sessions_n, AVG(session_minutes) AS avg_session_minutes
FROM clean_events GROUP BY device, variant
UNION ALL
SELECT 'plan', plan, variant, COUNT(*), SUM(clicked), SUM(converted), COUNT(session_minutes), AVG(session_minutes)
FROM clean_events GROUP BY plan, variant
UNION ALL
SELECT 'user_type', user_type, variant, COUNT(*), SUM(clicked), SUM(converted), COUNT(session_minutes), AVG(session_minutes)
FROM clean_events GROUP BY user_type, variant
